﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace MVCDotNetCoreMultipleFormsAndMultipleViews.Controllers
{
    public class FormsController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult ProcessCalculations(String number1, String number2)
        {
            Decimal num1 = Decimal.Parse(number1);
            Decimal num2 = Decimal.Parse(number2);
            ViewData["num1"] = num1;
            ViewData["num2"] = num2;
            ViewData["sum"] = num1 + num2;
            ViewData["difference"] = num1 - num2;
            ViewData["product"] = num1 * num2;
            ViewData["quotient"] = "Quotient: Cannot divide by zero!!!";
            if (num2 != 0m)
            {
                ViewData["quotient"] = num1 / num2;
            }
            return View("CalculatorResults");
        }

        [HttpGet]
        public IActionResult ProcessInformation(String first, String last, String gender, String month)
        {
            ViewData["first"] = first;
            ViewData["last"] = last;
            ViewData["gender"] = gender;
            ViewData["month"] = month;
            return View("InfoResults");
        }

        [HttpPost]
        public IActionResult ProcessMood(String mood)
        {
            ViewData["mood"] = mood;
            return View("MoodResults");
        }
    }
}